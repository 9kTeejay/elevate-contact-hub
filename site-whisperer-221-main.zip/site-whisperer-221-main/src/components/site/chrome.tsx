import { Link } from "@tanstack/react-router";
import { ArrowRight, Phone } from "lucide-react";

export function BackgroundFX() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10">
      <div className="absolute inset-0 bg-hero-radial" />
      <div className="absolute inset-0 bg-grid opacity-70" />
    </div>
  );
}

export function Nav() {
  const links: { label: string; href: string }[] = [
    { label: "Services", href: "/#services" },
    { label: "Work", href: "/#work" },
    { label: "Process", href: "/#process" },
    { label: "Pricing", href: "/pricing" },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-hairline backdrop-blur-xl bg-background/60">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <Link to="/" className="flex items-center gap-2.5 group">
          <span className="relative grid h-7 w-7 place-items-center rounded-md bg-gradient-to-br from-primary to-ember shadow-glow">
            <span className="h-2 w-2 rounded-full bg-background" />
          </span>
          <span className="font-display text-lg font-semibold tracking-tight">
            Northbound
          </span>
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) =>
            l.href.startsWith("/") && !l.href.includes("#") ? (
              <Link
                key={l.label}
                to={l.href}
                className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                activeProps={{ className: "text-sm text-foreground" }}
              >
                {l.label}
              </Link>
            ) : (
              <a
                key={l.label}
                href={l.href}
                className="text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {l.label}
              </a>
            ),
          )}
        </nav>
        <div className="flex items-center gap-3">
          <a
            href="tel:+18326224254"
            className="hidden items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground sm:flex"
          >
            <Phone className="h-3.5 w-3.5" />
            (832) 622-4254
          </a>
          <a
            href="/contact"
            className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:-translate-y-px"
          >
            Start Project <ArrowRight className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-hairline bg-surface/30">
      <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-6 py-10 md:flex-row md:items-center">
        <div className="flex items-center gap-2.5">
          <span className="grid h-6 w-6 place-items-center rounded-md bg-gradient-to-br from-primary to-ember">
            <span className="h-1.5 w-1.5 rounded-full bg-background" />
          </span>
          <span className="font-display text-sm font-semibold">Northbound</span>
        </div>
        <div className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} Northbound Growth Systems · Houston, TX ·
          Nxtchristmas@nr-financial.com
        </div>
        <div className="flex gap-5 text-xs text-muted-foreground">
          <Link to="/pricing" className="hover:text-foreground">Pricing</Link>
          <Link to="/about" className="hover:text-foreground">About</Link>
          <Link to="/contact" className="hover:text-foreground">Contact</Link>
        </div>
      </div>
    </footer>
  );
}

export function SectionHeader({
  eyebrow,
  title,
  intro,
}: {
  eyebrow?: string;
  title?: React.ReactNode;
  intro?: React.ReactNode;
}) {
  return (
    <div className="mb-14 max-w-3xl">
      {eyebrow && (
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full bg-primary animate-ticker" />
          {eyebrow}
        </div>
      )}
      {title && (
        <h1 className="font-display text-4xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
          {title}
        </h1>
      )}
      {intro && (
        <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
          {intro}
        </p>
      )}
    </div>
  );
}
