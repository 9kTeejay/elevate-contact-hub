import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowRight, Check } from "lucide-react";
import { BackgroundFX, Nav, Footer, SectionHeader } from "@/components/site/chrome";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing — Northbound Growth Systems" },
      {
        name: "description",
        content:
          "Transparent tiers, real deliverables, no lock-in games. From a starter presence to a done-for-you growth machine — pick the engagement sized to your ambition.",
      },
      { property: "og:title", content: "Pricing — Northbound Growth Systems" },
      {
        property: "og:description",
        content:
          "Four transparent engagement tiers plus an interactive estimator. Book a discovery call and we'll recommend the right starting point.",
      },
    ],
  }),
  component: PricingPage,
});

const TIERS = [
  {
    tier: "Tier 1",
    name: "Starter Website",
    price: "$450–$500",
    priceNote: "one-time",
    tagline: "Establish a credible presence in days, not months.",
    features: [
      "1-page or basic multi-page site",
      "Mobile-friendly design",
      "Contact form + click-to-call",
      "Google Maps embed",
      "Simple branding pass",
      "Fast delivery",
    ],
    cta: "Start Your Project",
    highlight: false,
  },
  {
    tier: "Tier 2",
    name: "Online Presence Setup",
    price: "$1,000–$2,500",
    priceNote: "one-time",
    tagline: "Everything a serious operator needs to win the local market.",
    features: [
      "Custom 5–7 page website",
      "Google Business Profile optimization",
      "Lead forms & tracking",
      "Foundational SEO setup",
      "Mobile & speed optimization",
      "Branding refinement",
    ],
    cta: "Grow My Business",
    highlight: true,
    badge: "Most popular",
  },
  {
    tier: "Tier 3",
    name: "Lead Generation System",
    price: "$3,000–$6,000",
    priceNote: "+ $300–$800/mo",
    tagline: "An operating system for compounding, predictable pipeline.",
    features: [
      "CRM setup & pipeline design",
      "Appointment booking flow",
      "Email marketing automation",
      "SMS automation",
      "Review generation engine",
      "Advanced local SEO",
    ],
    cta: "Generate More Leads",
    highlight: false,
  },
  {
    tier: "Tier 4",
    name: "Done-For-You Growth Machine",
    price: "$6,000–$15,000+",
    priceNote: "+ $800–$2,500/mo",
    tagline: "A full-stack customer acquisition engine, operated for you.",
    features: [
      "Google Ads management",
      "Meta Ads management",
      "Conversion landing pages",
      "AI chatbot deployment",
      "Analytics & attribution",
      "Monthly optimization sprints",
    ],
    cta: "Scale My Company",
    highlight: false,
  },
];

function PricingPage() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <BackgroundFX />
      <Nav />
      <main className="relative">
        <section className="pt-24 pb-8 md:pt-32">
          <div className="mx-auto max-w-7xl px-6">
            <SectionHeader
              eyebrow="Pricing"
              title={
                <>
                  Engagements sized to your{" "}
                  <span className="text-gradient">ambition</span>.
                </>
              }
              intro="Transparent tiers, real deliverables, no lock-in games. Not sure which tier fits? Book a discovery call and we'll recommend the right starting point."
            />
          </div>
        </section>

        <section className="pb-20 md:pb-28">
          <div className="mx-auto max-w-7xl px-6">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
              {TIERS.map((t) => (
                <TierCard key={t.name} {...t} />
              ))}
            </div>
          </div>
        </section>

        <Estimator />

        <section className="py-24 md:py-32">
          <div className="mx-auto max-w-5xl px-6">
            <div className="relative overflow-hidden rounded-3xl border border-hairline bg-surface/70 p-10 text-center md:p-14">
              <div aria-hidden className="pointer-events-none absolute inset-0 bg-hero-radial opacity-80" />
              <div className="relative">
                <h2 className="font-display text-3xl font-semibold leading-tight tracking-tight md:text-5xl">
                  Still not sure which tier?{" "}
                  <span className="text-gradient">We'll tell you.</span>
                </h2>
                <p className="mx-auto mt-4 max-w-xl text-sm text-muted-foreground md:text-base">
                  30-minute discovery call. We'll audit where you're losing
                  customers today and recommend the smallest engagement that
                  moves the needle.
                </p>
                <a
                  href="/#contact"
                  className="mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:-translate-y-px"
                >
                  Book Discovery Call
                  <ArrowRight className="h-4 w-4" />
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}

function TierCard({
  tier,
  name,
  price,
  priceNote,
  tagline,
  features,
  cta,
  highlight,
  badge,
}: (typeof TIERS)[number]) {
  return (
    <article
      className={`hairline shadow-card relative flex flex-col rounded-2xl p-7 transition-transform hover:-translate-y-1 ${
        highlight
          ? "bg-gradient-to-b from-primary/[0.09] to-surface/60 ring-1 ring-primary/40"
          : "bg-surface/60"
      }`}
    >
      {badge && (
        <span className="absolute -top-3 left-6 rounded-full bg-primary px-2.5 py-1 font-mono text-[10px] uppercase tracking-widest text-primary-foreground shadow-glow">
          {badge}
        </span>
      )}
      <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
        {tier}
      </div>
      <h3 className="mt-3 font-display text-xl font-semibold tracking-tight">
        {name}
      </h3>
      <div className="mt-5 flex items-baseline gap-2">
        <span className="font-display text-3xl font-semibold tracking-tight md:text-4xl">
          {price}
        </span>
      </div>
      <div className="mt-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
        {priceNote}
      </div>
      <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
        {tagline}
      </p>
      <ul className="mt-6 space-y-2.5 border-t border-hairline pt-6">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2 text-sm text-foreground/90">
            <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
            <span>{f}</span>
          </li>
        ))}
      </ul>
      <a
        href="/#contact"
        className={`mt-7 inline-flex items-center justify-center gap-1.5 rounded-full px-5 py-3 text-sm font-medium transition-transform hover:-translate-y-px ${
          highlight
            ? "bg-primary text-primary-foreground shadow-glow"
            : "border border-hairline bg-background text-foreground hover:bg-surface"
        }`}
      >
        {cta} <ArrowRight className="h-3.5 w-3.5" />
      </a>
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* Estimator                                                           */
/* ------------------------------------------------------------------ */

const SCOPE_OPTIONS = [
  { key: "starter", label: "Starter", oneTime: 475, monthly: 0 },
  { key: "presence", label: "Presence", oneTime: 1800, monthly: 0 },
  { key: "leadgen", label: "Lead Gen", oneTime: 4500, monthly: 550 },
  { key: "growth", label: "Growth", oneTime: 10000, monthly: 1600 },
] as const;

const ADDONS = [
  { key: "seo", label: "Advanced SEO", monthly: 600 },
  { key: "ads", label: "Paid ads mgmt", monthly: 900 },
  { key: "chatbot", label: "AI chatbot", monthly: 250 },
  { key: "crmops", label: "CRM ops", monthly: 400 },
] as const;

function Estimator() {
  const [scope, setScope] = useState<(typeof SCOPE_OPTIONS)[number]["key"]>("presence");
  const [addons, setAddons] = useState<Set<string>>(new Set());

  const totals = useMemo(() => {
    const s = SCOPE_OPTIONS.find((o) => o.key === scope)!;
    const addonMonthly = ADDONS.filter((a) => addons.has(a.key)).reduce(
      (sum, a) => sum + a.monthly,
      0,
    );
    const monthly = s.monthly + addonMonthly;
    const roiFactor = 15; // illustrative — matches Atlas's "compounding" framing
    const roi = Math.round((s.oneTime + monthly * 12) * (roiFactor / 12)); // ~ 15x annualized
    return { oneTime: s.oneTime, monthly, roi };
  }, [scope, addons]);

  const toggleAddon = (k: string) => {
    setAddons((prev) => {
      const next = new Set(prev);
      if (next.has(k)) next.delete(k);
      else next.add(k);
      return next;
    });
  };

  return (
    <section className="py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-10 max-w-2xl">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-ticker" />
            Interactive estimator
          </div>
          <h2 className="font-display text-3xl font-semibold leading-tight tracking-tight md:text-5xl">
            Model your <span className="text-gradient">engagement</span>.
          </h2>
          <p className="mt-4 text-base text-muted-foreground md:text-lg">
            A quick way to explore scope. Actual scope confirmed during
            discovery.
          </p>
        </div>

        <div className="hairline shadow-card grid grid-cols-1 gap-8 rounded-2xl bg-surface/60 p-6 md:grid-cols-[1fr_1fr] md:p-10">
          {/* Controls */}
          <div className="space-y-8">
            <div>
              <div className="mb-3 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                Project scope
              </div>
              <div className="grid grid-cols-2 gap-2">
                {SCOPE_OPTIONS.map((o) => (
                  <button
                    key={o.key}
                    onClick={() => setScope(o.key)}
                    className={`rounded-lg border px-4 py-3 text-left text-sm transition-colors ${
                      scope === o.key
                        ? "border-primary bg-primary/10 text-foreground shadow-glow"
                        : "border-hairline bg-background text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {o.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="mb-3 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                Monthly add-ons
              </div>
              <div className="grid grid-cols-2 gap-2">
                {ADDONS.map((a) => {
                  const on = addons.has(a.key);
                  return (
                    <button
                      key={a.key}
                      onClick={() => toggleAddon(a.key)}
                      className={`flex items-center justify-between rounded-lg border px-4 py-3 text-left text-sm transition-colors ${
                        on
                          ? "border-primary bg-primary/10 text-foreground"
                          : "border-hairline bg-background text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      <span>{a.label}</span>
                      <span
                        className={`grid h-4 w-4 place-items-center rounded-sm border ${
                          on
                            ? "border-primary bg-primary text-primary-foreground"
                            : "border-hairline"
                        }`}
                      >
                        {on && <Check className="h-3 w-3" />}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Result */}
          <div className="rounded-xl border border-hairline bg-background/60 p-6">
            <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
              Estimated engagement
            </div>
            <div className="mt-3 flex flex-wrap items-baseline gap-x-6 gap-y-2">
              <div>
                <div className="font-display text-4xl font-semibold tracking-tight md:text-5xl">
                  ${totals.oneTime.toLocaleString()}
                </div>
                <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                  one-time
                </div>
              </div>
              <div className="text-3xl text-muted-foreground/50">+</div>
              <div>
                <div className="font-display text-4xl font-semibold tracking-tight text-primary md:text-5xl">
                  ${totals.monthly.toLocaleString()}
                </div>
                <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                  /month
                </div>
              </div>
            </div>

            <div className="mt-8 border-t border-hairline pt-6">
              <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                ROI illustration (12 mo)
              </div>
              <div className="mt-2 font-display text-2xl font-semibold text-ember md:text-3xl">
                ~ ${totals.roi.toLocaleString()}
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Estimates vary by market, offer, and execution. Illustrative
                only — not a projection or guarantee.
              </p>
            </div>

            <a
              href="/#contact"
              className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:-translate-y-px"
            >
              Book Discovery <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
