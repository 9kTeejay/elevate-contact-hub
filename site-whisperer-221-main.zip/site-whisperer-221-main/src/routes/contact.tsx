import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Mail, Phone, MapPin, Check, AlertCircle, Loader2 } from "lucide-react";
import { BackgroundFX, Nav, Footer, SectionHeader } from "@/components/site/chrome";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Northbound Growth Systems" },
      {
        name: "description",
        content:
          "Tell us about your business and goals. We reply within one business day with a plan, not a pitch.",
      },
      { property: "og:title", content: "Contact — Northbound Growth Systems" },
      {
        property: "og:description",
        content:
          "Book a 20-minute strategy call or send us the details of your project. Houston-based, serving local market leaders.",
      },
    ],
  }),
  component: ContactPage,
});

const SERVICES = [
  "Website / Redesign",
  "SEO & Google Business",
  "Google & Meta Ads",
  "CRM & Automation",
  "Booking & SMS/Email",
  "AI Chatbot",
  "Full Growth System",
  "Not sure yet",
];

const BUDGETS = [
  "Under $2k",
  "$2k – $5k",
  "$5k – $10k",
  "$10k – $25k",
  "$25k+",
];

function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    business: "",
    email: "",
    phone: "",
    website: "",
    service: "",
    budget: "",
    timeline: "",
    message: "",
  });

  function update<K extends keyof typeof form>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    setErrorMsg(null);
    setSubmitting(true);
    try {
      const res = await fetch("https://formspree.io/f/xdaqeeve", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          ...form,
          _subject: `New inquiry from ${form.name || "website"} (${form.business || "—"})`,
        }),
      });
      if (!res.ok) {
        let msg = "Something went wrong. Please try again or email us directly.";
        try {
          const data = await res.json();
          if (data?.errors?.[0]?.message) msg = data.errors[0].message;
        } catch {}
        throw new Error(msg);
      }
      setSubmitted(true);
      setForm({
        name: "",
        business: "",
        email: "",
        phone: "",
        website: "",
        service: "",
        budget: "",
        timeline: "",
        message: "",
      });
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : "Something went wrong. Please try again.",
      );
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <BackgroundFX />
      <Nav />

      <section className="mx-auto max-w-7xl px-6 pt-20 pb-10">
        <SectionHeader
          eyebrow="Contact"
          title={
            <>
              Tell us where you want to go.<br />
              <span className="text-muted-foreground">We'll map the route.</span>
            </>
          }
          intro="Share a few details about your business. You'll get a real reply from a human within one business day — with a specific next step, not a generic sales pitch."
        />
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-24">
        <div className="grid gap-10 lg:grid-cols-[1fr_1.6fr]">
          {/* Side info */}
          <aside className="space-y-6">
            <div className="rounded-2xl border border-hairline bg-surface/40 p-6">
              <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                Direct lines
              </div>
              <div className="mt-4 space-y-3 text-sm">
                <a href="tel:+18326224254" className="flex items-center gap-3 hover:text-primary">
                  <Phone className="h-4 w-4 text-primary" />
                  (832) 622-4254
                </a>
                <a href="mailto:Nxtchristmas@nr-financial.com" className="flex items-center gap-3 hover:text-primary">
                  <Mail className="h-4 w-4 text-primary" />
                  Nxtchristmas@nr-financial.com
                </a>
                <div className="flex items-center gap-3 text-muted-foreground">
                  <MapPin className="h-4 w-4 text-primary" />
                  Houston, TX · Serving nationwide
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-hairline bg-surface/40 p-6">
              <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                What happens next
              </div>
              <ol className="mt-4 space-y-3 text-sm">
                {[
                  "We review your submission and pull public data on your market.",
                  "You get a reply within 1 business day with a proposed call time.",
                  "20-minute discovery call — we outline a plan, whether you hire us or not.",
                ].map((step, i) => (
                  <li key={step} className="flex gap-3">
                    <span className="mt-0.5 grid h-5 w-5 flex-none place-items-center rounded-full bg-primary/15 font-mono text-[11px] text-primary">
                      {i + 1}
                    </span>
                    <span className="text-muted-foreground">{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            <div className="rounded-2xl border border-hairline bg-gradient-to-br from-primary/10 to-ember/5 p-6">
              <div className="font-mono text-[11px] uppercase tracking-widest text-primary">
                Response window
              </div>
              <div className="mt-2 font-display text-2xl font-semibold">
                &lt; 1 business day
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                No auto-responders. No SDR queues. Replies come from the person who'd actually run your account.
              </p>
            </div>
          </aside>

          {/* Form */}
          <div className="rounded-2xl border border-hairline bg-surface/40 p-6 md:p-8">
            {submitted ? (
              <div className="flex min-h-[520px] flex-col items-center justify-center text-center">
                <div className="grid h-14 w-14 place-items-center rounded-full bg-primary/15">
                  <Check className="h-7 w-7 text-primary" />
                </div>
                <h2 className="mt-6 font-display text-2xl font-semibold">
                  Thank you!
                </h2>
                <p className="mt-3 max-w-md text-sm text-muted-foreground">
                  Your request has been received. We'll be in touch shortly.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setErrorMsg(null);
                  }}
                  className="mt-8 text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
                >
                  Submit another
                </button>
              </div>
            ) : (
              <form onSubmit={onSubmit} noValidate className="space-y-5">
                <div className="grid gap-5 md:grid-cols-2">
                  <Field label="Your name" required>
                    <input
                      required
                      name="name"
                      value={form.name}
                      onChange={(e) => update("name", e.target.value)}
                      className={inputCls}
                      placeholder="Jane Rivera"
                    />
                  </Field>
                  <Field label="Business name" required>
                    <input
                      required
                      name="business"
                      value={form.business}
                      onChange={(e) => update("business", e.target.value)}
                      className={inputCls}
                      placeholder="Rivera Roofing Co."
                    />
                  </Field>
                  <Field label="Email" required>
                    <input
                      required
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={(e) => update("email", e.target.value)}
                      className={inputCls}
                      placeholder="you@company.com"
                    />
                  </Field>
                  <Field label="Phone">
                    <input
                      type="tel"
                      name="phone"
                      value={form.phone}
                      onChange={(e) => update("phone", e.target.value)}
                      className={inputCls}
                      placeholder="(555) 123-4567"
                    />
                  </Field>
                  <Field label="Current website" className="md:col-span-2">
                    <input
                      name="website"
                      value={form.website}
                      onChange={(e) => update("website", e.target.value)}
                      className={inputCls}
                      placeholder="https://…  (or 'none yet')"
                    />
                  </Field>

                  <Field label="What do you need?" required>
                    <select
                      required
                      name="service"
                      value={form.service}
                      onChange={(e) => update("service", e.target.value)}
                      className={inputCls}
                    >
                      <option value="">Select a focus…</option>
                      {SERVICES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="Monthly budget">
                    <select
                      name="budget"
                      value={form.budget}
                      onChange={(e) => update("budget", e.target.value)}
                      className={inputCls}
                    >
                      <option value="">Select a range…</option>
                      {BUDGETS.map((b) => (
                        <option key={b} value={b}>
                          {b}
                        </option>
                      ))}
                    </select>
                  </Field>

                  <Field label="Ideal timeline" className="md:col-span-2">
                    <input type="hidden" name="timeline" value={form.timeline} />
                    <div className="flex flex-wrap gap-2">
                      {["ASAP", "2–4 weeks", "1–2 months", "Just exploring"].map(
                        (t) => {
                          const active = form.timeline === t;
                          return (
                            <button
                              key={t}
                              type="button"
                              onClick={() => update("timeline", t)}
                              className={
                                "rounded-full border px-3 py-1.5 text-xs transition " +
                                (active
                                  ? "border-primary bg-primary/15 text-primary"
                                  : "border-hairline text-muted-foreground hover:text-foreground")
                              }
                            >
                              {t}
                            </button>
                          );
                        },
                      )}
                    </div>
                  </Field>

                  <Field label="Tell us about the project" className="md:col-span-2">
                    <textarea
                      rows={5}
                      name="message"
                      value={form.message}
                      onChange={(e) => update("message", e.target.value)}
                      className={inputCls + " resize-none"}
                      placeholder="Where you are today, where you want to go, and anything you've already tried."
                      maxLength={2000}
                    />
                  </Field>
                </div>

                {errorMsg && (
                  <div
                    role="alert"
                    className="flex items-start gap-2 rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive"
                  >
                    <AlertCircle className="mt-0.5 h-4 w-4 flex-none" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <div className="flex flex-col-reverse items-start justify-between gap-4 border-t border-hairline pt-5 sm:flex-row sm:items-center">
                  <p className="text-xs text-muted-foreground">
                    We reply from a real inbox. No lists, no spam — ever.
                  </p>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:-translate-y-px disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:translate-y-0"
                  >
                    {submitting ? (
                      <>
                        Sending… <Loader2 className="h-4 w-4 animate-spin" />
                      </>
                    ) : (
                      <>
                        Send it over <ArrowRight className="h-4 w-4" />
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

const inputCls =
  "w-full rounded-lg border border-hairline bg-background/60 px-3.5 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/60 outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20";

function Field({
  label,
  required,
  className = "",
  children,
}: {
  label: string;
  required?: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <label className={"block " + className}>
      <span className="mb-1.5 block font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
        {label}
        {required && <span className="ml-1 text-primary">*</span>}
      </span>
      {children}
    </label>
  );
}