import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Star } from "lucide-react";
import { BackgroundFX, Nav, Footer, SectionHeader } from "@/components/site/chrome";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Northbound Growth Systems" },
      {
        name: "description",
        content:
          "Northbound is a small growth-infrastructure team that installs and operates the full acquisition system for local market leaders — accountable to your pipeline, not our deck pages.",
      },
      { property: "og:title", content: "About — Northbound Growth Systems" },
      {
        property: "og:description",
        content:
          "We build digital assets, not digital brochures. Embedded like an internal squad, held to the same metrics you are.",
      },
    ],
  }),
  component: AboutPage,
});

const PRINCIPLES = [
  {
    name: "Craft as competitive advantage",
    desc: "Detail is compounding leverage. We sweat it so your competitors have to explain why they didn't.",
  },
  {
    name: "Performance over posture",
    desc: "We measure ourselves in shipped work and moved metrics — not deck pages or industry awards.",
  },
  {
    name: "Systems over sprints",
    desc: "One-off wins fade. We install operating systems your team can run on for years.",
  },
  {
    name: "Partnership, not procurement",
    desc: "We turn away work where we can't have a real seat at the table. Long-term partnerships build the best work.",
  },
];

const FEEDBACK = [
  {
    q: "Northbound rebuilt the surface our brand runs on. It's the first time our marketing site actually feels like the product.",
    who: "Head of Growth",
  },
  {
    q: "In eight weeks they replaced a stack we'd spent two years assembling — and it converts twice as well.",
    who: "Founder",
  },
  {
    q: "The difference between Northbound and every other agency we tried is the quality of the thinking, not just the pixels.",
    who: "CMO",
  },
];

function AboutPage() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <BackgroundFX />
      <Nav />
      <main className="relative">
        {/* Hero */}
        <section className="pt-24 pb-16 md:pt-32 md:pb-24">
          <div className="mx-auto max-w-7xl px-6">
            <SectionHeader
              eyebrow="About"
              title={
                <>
                  We build digital{" "}
                  <span className="text-gradient">assets</span>, not digital
                  brochures.
                </>
              }
            />
            <div className="grid max-w-4xl gap-6 text-base leading-relaxed text-muted-foreground md:text-lg">
              <p>
                Northbound exists for founders and operators who understand a
                website is a piece of business infrastructure — not a brochure
                to be reprinted every three years. We work with a small number
                of ambitious teams each quarter, embedded like an internal
                squad, and hold ourselves accountable to the same metrics they
                do.
              </p>
              <p>
                Everything we build is designed to compound: a brand you can
                grow into, systems your team can operate, and infrastructure
                that keeps paying dividends long after the initial engagement
                ends. We measure success in{" "}
                <span className="text-foreground">customer velocity, pipeline created, and category ownership</span>{" "}
                — not deck pages.
              </p>
            </div>
          </div>
        </section>

        {/* Principles */}
        <section className="py-16 md:py-24">
          <div className="mx-auto max-w-7xl px-6">
            <div className="mb-10 max-w-2xl">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-primary animate-ticker" />
                Operating principles
              </div>
              <h2 className="font-display text-3xl font-semibold leading-tight tracking-tight md:text-5xl">
                Obsessions we{" "}
                <span className="text-gradient">won't outgrow</span>.
              </h2>
            </div>
            <div className="grid grid-cols-1 gap-px bg-hairline md:grid-cols-2">
              {PRINCIPLES.map((p, i) => (
                <div key={p.name} className="bg-background p-8">
                  <div className="font-mono text-[11px] text-muted-foreground">
                    {String(i + 1).padStart(2, "0")}
                  </div>
                  <h3 className="mt-3 font-display text-xl font-semibold tracking-tight">
                    {p.name}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-muted-foreground md:text-base">
                    {p.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Feedback */}
        <section className="py-16 md:py-24">
          <div className="mx-auto max-w-7xl px-6">
            <div className="mb-10 max-w-2xl">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-ember animate-ticker" />
                Client feedback examples
              </div>
              <h2 className="font-display text-3xl font-semibold leading-tight tracking-tight md:text-5xl">
                Representative quotes,{" "}
                <span className="text-gradient">honestly labeled</span>.
              </h2>
              <p className="mt-4 text-sm text-muted-foreground md:text-base">
                Shown here until replaced with verified, named testimonials
                from finished engagements.
              </p>
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              {FEEDBACK.map((f, i) => (
                <figure
                  key={i}
                  className="hairline shadow-card flex flex-col rounded-2xl bg-surface/60 p-7"
                >
                  <div className="flex gap-0.5 text-primary">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <blockquote className="mt-5 flex-1 font-display text-lg leading-snug text-foreground">
                    "{f.q}"
                  </blockquote>
                  <figcaption className="mt-6 border-t border-hairline pt-4">
                    <div className="text-sm font-medium text-foreground">
                      {f.who}
                    </div>
                    <div className="mt-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                      Client feedback example
                    </div>
                  </figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-24 md:py-32">
          <div className="mx-auto max-w-5xl px-6">
            <div className="relative overflow-hidden rounded-3xl border border-hairline bg-surface/70 p-10 text-center md:p-14">
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 bg-hero-radial opacity-80"
              />
              <div className="relative">
                <h2 className="font-display text-3xl font-semibold leading-tight tracking-tight md:text-5xl">
                  Want to <span className="text-gradient">work with us</span>?
                </h2>
                <p className="mx-auto mt-4 max-w-xl text-sm text-muted-foreground md:text-base">
                  We take a small number of engagements each quarter. Share
                  your goals — we'll respond within one business day.
                </p>
                <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
                  <a
                    href="/#contact"
                    className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:-translate-y-px"
                  >
                    Start Your Project <ArrowRight className="h-4 w-4" />
                  </a>
                  <a
                    href="/#process"
                    className="inline-flex items-center gap-2 rounded-full border border-hairline bg-background/60 px-6 py-3.5 text-sm font-medium text-foreground transition-colors hover:bg-background"
                  >
                    See Our Process
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
