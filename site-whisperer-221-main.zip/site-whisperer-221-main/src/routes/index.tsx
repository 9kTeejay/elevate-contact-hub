import { createFileRoute } from "@tanstack/react-router";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  Minus,
  Phone,
  Zap,
  Search,
  Star,
  MessageSquare,
  Calendar,
  Mail,
  Bot,
  Globe,
  MapPin,
  Target,
  Users,
  LineChart,
} from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { BackgroundFX, Nav, Footer } from "@/components/site/chrome";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title:
          "Northbound — Growth Infrastructure for Local Market Leaders",
      },
      {
        name: "description",
        content:
          "We engineer the full growth system — website, SEO, ads, CRM, and AI automation — so local businesses turn every search into booked, predictable revenue.",
      },
    ],
  }),
  component: HomePage,
});

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

function HomePage() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <BackgroundFX />
      <Nav />
      <main className="relative">
        <Hero />
        <DashboardCard />
        <Pipeline />
        <StatStrip />
        <Services />
        <CaseStudies />
        <Process />
        <Comparison />
        <Industries />
        <Testimonials />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}

/* ------------------------------------------------------------------ */

/* ------------------------------------------------------------------ */
/* Section shell                                                       */
/* ------------------------------------------------------------------ */

function Section({
  id,
  eyebrow,
  title,
  intro,
  children,
  className = "",
}: {
  id?: string;
  eyebrow?: string;
  title?: React.ReactNode;
  intro?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={`relative py-24 md:py-32 ${className}`}>
      <div className="mx-auto max-w-7xl px-6">
        {(eyebrow || title || intro) && (
          <div className="mb-14 max-w-3xl">
            {eyebrow && (
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-primary animate-ticker" />
                {eyebrow}
              </div>
            )}
            {title && (
              <h2 className="font-display text-4xl font-semibold leading-[1.05] tracking-tight md:text-5xl">
                {title}
              </h2>
            )}
            {intro && (
              <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
                {intro}
              </p>
            )}
          </div>
        )}
        {children}
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Hero                                                                */
/* ------------------------------------------------------------------ */

function Hero() {
  return (
    <section className="relative pt-24 pb-8 md:pt-36">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mx-auto max-w-4xl">
          <div className="inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-ember animate-ticker" />
            Now booking Q4 partnerships · 3 slots left
          </div>

          <h1 className="mt-6 font-display text-5xl font-semibold leading-[0.98] tracking-tight md:text-7xl lg:text-[5.5rem]">
            Turn local searches into{" "}
            <span className="text-gradient">booked revenue</span> — on
            autopilot.
          </h1>

          <p className="mt-7 max-w-2xl text-lg leading-relaxed text-muted-foreground md:text-xl">
            Northbound engineers the full growth system —{" "}
            <span className="text-foreground">website, SEO, ads, CRM, and AI automation</span>{" "}
            — so every dollar you spend compounds into predictable weekly
            revenue. No vendors to coordinate. No leaks. No lock-in.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:-translate-y-px"
            >
              Book a Free Strategy Call
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </a>
            <a
              href="#work"
              className="inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-6 py-3.5 text-sm font-medium text-foreground transition-colors hover:bg-surface"
            >
              See the work
            </a>
            <a
              href="tel:+18326224254"
              className="inline-flex items-center gap-2 px-3 py-3.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <Phone className="h-4 w-4" />
              (832) 622-4254
            </a>
          </div>

          <p className="mt-5 text-xs text-muted-foreground">
            No contracts. No lock-in. We earn your business every month.
          </p>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Dashboard card (Atlas-style KPI mockup)                             */
/* ------------------------------------------------------------------ */

function DashboardCard() {
  return (
    <section className="relative pb-16 md:pb-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="hairline shadow-card relative overflow-hidden rounded-2xl bg-surface/70 backdrop-blur">
          {/* window chrome */}
          <div className="flex items-center justify-between border-b border-hairline px-5 py-3">
            <div className="flex items-center gap-3">
              <div className="flex gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-muted-foreground/40" />
                <span className="h-2.5 w-2.5 rounded-full bg-muted-foreground/40" />
                <span className="h-2.5 w-2.5 rounded-full bg-muted-foreground/40" />
              </div>
              <span className="font-mono text-xs text-muted-foreground">
                northbound.dashboard / live
              </span>
            </div>
            <span className="inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-ember animate-ticker" />
              streaming
            </span>
          </div>

          {/* KPI grid */}
          <div className="grid grid-cols-2 gap-px bg-hairline md:grid-cols-4">
            <KPI
              label="Pipeline (30d)"
              value="$1.4M"
              delta="+34.2% MoM"
              trend="up"
            />
            <KPI
              label="Booked Calls"
              value="218"
              delta="+62 this week"
              trend="up"
            />
            <KPI
              label="Blended ROAS"
              value="9.4×"
              delta="rolling 30d"
              trend="neutral"
            />
            <KPI
              label="Lead → Reply"
              value="<5 min"
              delta="automated"
              trend="neutral"
            />
          </div>

          {/* fake chart bar */}
          <div className="border-t border-hairline p-5">
            <div className="flex items-end gap-1.5 h-24">
              {[38, 52, 44, 61, 55, 72, 68, 84, 79, 92, 88, 96, 90, 100].map(
                (h, i) => (
                  <div
                    key={i}
                    className="flex-1 rounded-sm bg-gradient-to-t from-primary/20 to-primary/70"
                    style={{ height: `${h}%` }}
                  />
                ),
              )}
            </div>
            <div className="mt-3 flex items-center justify-between font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
              <span>booked appointments · last 14 days</span>
              <span className="text-primary">▲ compounding</span>
            </div>
          </div>
        </div>
        <p className="mt-3 text-center text-xs text-muted-foreground">
          Illustrative dashboard — representative of the reporting surface every
          engagement ships with.
        </p>
      </div>
    </section>
  );
}

function KPI({
  label,
  value,
  delta,
  trend,
}: {
  label: string;
  value: string;
  delta: string;
  trend: "up" | "down" | "neutral";
}) {
  return (
    <div className="bg-surface p-5">
      <div className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      <div className="mt-2 font-display text-3xl font-semibold tracking-tight md:text-4xl">
        {value}
      </div>
      <div
        className={`mt-1 text-xs ${
          trend === "up" ? "text-ember" : "text-muted-foreground"
        }`}
      >
        {delta}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Pipeline (animated 6 steps)                                         */
/* ------------------------------------------------------------------ */

const PIPELINE_STEPS = [
  { n: "01", label: "Search", sub: "Google / Maps", Icon: Search },
  { n: "02", label: "Visit", sub: "Fast site + GBP", Icon: Globe },
  { n: "03", label: "Capture", sub: "Form / Chat / Call", Icon: MessageSquare },
  { n: "04", label: "Nurture", sub: "SMS + Email", Icon: Zap },
  { n: "05", label: "Book", sub: "Auto calendar", Icon: Calendar },
  { n: "06", label: "Retain", sub: "Reviews + repeat", Icon: Star },
];

function Pipeline() {
  return (
    <Section
      id="pipeline"
      eyebrow="The pipeline"
      title={
        <>
          Six steps, one connected{" "}
          <span className="text-gradient">customer engine</span>.
        </>
      }
      intro="Every channel we deploy plugs into the same loop — so a click doesn't die in a landing page and a lead doesn't rot in an inbox."
    >
      <div className="hairline shadow-card rounded-2xl bg-surface/60 p-6 md:p-10">
        {/* Desktop horizontal */}
        <div className="relative hidden md:block">
          <div className="absolute left-6 right-6 top-[46px] h-px bg-hairline" />
          <div
            className="absolute top-[42px] h-2 w-2 rounded-full bg-primary shadow-glow animate-pipeline-travel"
            style={{ left: 0 }}
          />
          <div className="relative grid grid-cols-6 gap-4">
            {PIPELINE_STEPS.map((s) => (
              <div key={s.n} className="flex flex-col items-center text-center">
                <div className="font-mono text-[11px] text-muted-foreground">
                  {s.n}
                </div>
                <div className="mt-2 mb-4 grid h-11 w-11 place-items-center rounded-full border border-hairline bg-background">
                  <span className="h-2.5 w-2.5 rounded-full bg-primary animate-pipeline-pulse" />
                </div>
                <div className="font-display text-base font-semibold">
                  {s.label}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {s.sub}
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* Mobile vertical */}
        <div className="md:hidden space-y-4">
          {PIPELINE_STEPS.map((s) => (
            <div key={s.n} className="flex items-center gap-4 rounded-lg border border-hairline bg-background p-3">
              <div className="grid h-9 w-9 place-items-center rounded-full border border-hairline">
                <s.Icon className="h-4 w-4 text-primary" />
              </div>
              <div>
                <div className="font-mono text-[10px] text-muted-foreground">{s.n}</div>
                <div className="font-display text-sm font-semibold">{s.label}</div>
                <div className="text-xs text-muted-foreground">{s.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------------ */
/* Stat strip                                                          */
/* ------------------------------------------------------------------ */

const STATS = [
  { k: "11", v: "Growth channels, one system" },
  { k: "<5m", v: "Avg. lead response time" },
  { k: "3.1×", v: "Avg. lift in booked appointments*" },
  { k: "24/7", v: "Coverage across every channel" },
];

function StatStrip() {
  return (
    <section className="border-y border-hairline bg-surface/40">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px bg-hairline md:grid-cols-4">
        {STATS.map((s) => (
          <div key={s.v} className="bg-background p-6 md:p-8">
            <div className="font-display text-4xl font-semibold tracking-tight text-foreground md:text-5xl">
              {s.k}
            </div>
            <div className="mt-2 text-sm text-muted-foreground">{s.v}</div>
          </div>
        ))}
      </div>
      <p className="mx-auto max-w-7xl px-6 py-3 text-[11px] text-muted-foreground">
        *Representative lift observed in portfolio and concept engagements; not
        an audited client average.
      </p>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Services                                                            */
/* ------------------------------------------------------------------ */

const SERVICES = [
  {
    cat: "Foundation",
    name: "Website Development",
    desc: "A fast, mobile-first site engineered to turn visitors into inquiries — not a brochure.",
    Icon: Globe,
  },
  {
    cat: "Visibility",
    name: "Google Business Profile",
    desc: "An optimized profile that puts you in the local map pack for the searches that matter.",
    Icon: MapPin,
  },
  {
    cat: "Visibility",
    name: "SEO",
    desc: "Rank for the exact searches your customers use — near-me, service-specific, high-intent.",
    Icon: Search,
  },
  {
    cat: "Trust",
    name: "Google Reviews",
    desc: "Automated request, capture, and display — building social proof before a customer ever calls.",
    Icon: Star,
  },
  {
    cat: "Demand",
    name: "Google Ads",
    desc: "Capture the exact moment customers search, with targeting built around your service area.",
    Icon: Target,
  },
  {
    cat: "Demand",
    name: "Meta Ads",
    desc: "Stay top of mind with warm audiences and reach new customers who look like your best.",
    Icon: Users,
  },
  {
    cat: "Conversion",
    name: "CRM Setup",
    desc: "Every lead lands in one place, tagged and tracked — nothing slips through the cracks.",
    Icon: LineChart,
  },
  {
    cat: "Conversion",
    name: "Appointment Booking",
    desc: "Self-serve calendar that lets customers grab a slot in seconds — no phone tag.",
    Icon: Calendar,
  },
  {
    cat: "Conversion",
    name: "SMS Marketing",
    desc: "Instant text follow-up the second someone reaches out — the biggest single lever on show-up rate.",
    Icon: MessageSquare,
  },
  {
    cat: "Retention",
    name: "Email Marketing",
    desc: "Automated nurture that brings past leads and customers back the moment they're ready.",
    Icon: Mail,
  },
  {
    cat: "Automation",
    name: "AI Chatbot",
    desc: "A 24/7 assistant that answers, qualifies, and books appointments while you're working.",
    Icon: Bot,
  },
];

function Services() {
  return (
    <Section
      id="services"
      eyebrow="What we build"
      title={
        <>
          Eleven capabilities. One{" "}
          <span className="text-gradient">coordinated engine</span>.
        </>
      }
      intro="Deploy the whole stack, or start with the single piece unblocking growth first. Every module is designed to plug into the next — no bolted-on vendors."
    >
      <div className="grid grid-cols-1 gap-px bg-hairline sm:grid-cols-2 lg:grid-cols-3">
        {SERVICES.map((s, i) => (
          <ServiceCard key={s.name} {...s} n={String(i + 1).padStart(2, "0")} />
        ))}
      </div>
    </Section>
  );
}

function ServiceCard({
  cat,
  name,
  desc,
  Icon,
  n,
}: {
  cat: string;
  name: string;
  desc: string;
  Icon: typeof Globe;
  n: string;
}) {
  return (
    <div className="group relative bg-background p-8 transition-colors hover:bg-surface">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[11px] uppercase tracking-widest text-primary">
          {cat}
        </span>
        <span className="font-mono text-[11px] text-muted-foreground">{n}</span>
      </div>
      <div className="mt-6 mb-4 grid h-11 w-11 place-items-center rounded-lg border border-hairline bg-surface/60 text-primary">
        <Icon className="h-5 w-5" />
      </div>
      <h3 className="font-display text-xl font-semibold tracking-tight">
        {name}
      </h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
        {desc}
      </p>
      <div className="mt-6 inline-flex items-center gap-1 text-xs text-muted-foreground transition-colors group-hover:text-primary">
        Explore <ArrowUpRight className="h-3.5 w-3.5" />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Case studies                                                        */
/* ------------------------------------------------------------------ */

const CASES = [
  {
    industry: "Roofing",
    tag: "Representative build",
    name: "Ironline Roofing Co.",
    outcome: "$1.4M pipeline example",
    desc: "Portfolio-first site with quote engine, storm-response funnel, and lifecycle nurture.",
  },
  {
    industry: "Medical",
    tag: "Representative build",
    name: "North Vertex Health",
    outcome: "3.2× booked consultations",
    desc: "Multi-location practice with intake automation, insurance qualifier, and referral loop.",
  },
  {
    industry: "Law Firm",
    tag: "Concept showcase",
    name: "Halden & Ross",
    outcome: "+62% intake conversion",
    desc: "Trust-forward brand system with case-intake flow and CRM sync to paralegals.",
  },
  {
    industry: "Home Services",
    tag: "Representative build",
    name: "Beacon HVAC",
    outcome: "9.4× blended ROAS",
    desc: "Local SEO + booking flow tuned to peak-season demand and after-hours capture.",
  },
  {
    industry: "Restaurant",
    tag: "Concept showcase",
    name: "Meridian Kitchen",
    outcome: "+180% qualified leads",
    desc: "Chef-driven concept with reservation flow, waitlist SMS, and loyalty engine.",
  },
  {
    industry: "Beauty",
    tag: "Representative build",
    name: "Maison Lys",
    outcome: "+240% returning bookings",
    desc: "Editorial brand system with product commerce and clienteling automation.",
  },
];

function CaseStudies() {
  return (
    <Section
      id="work"
      eyebrow="Featured work"
      title={
        <>
          Portfolio & concept builds —{" "}
          <span className="text-gradient">clearly labeled</span>.
        </>
      }
      intro="A curated showcase of the caliber we ship. Projects are labeled as representative or concept until they're replaced with verified, audited client engagements."
    >
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {CASES.map((c) => (
          <article
            key={c.name}
            className="group hairline shadow-card flex flex-col rounded-2xl bg-surface/60 p-7 transition-transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
                {c.industry}
              </span>
              <span className="rounded-full border border-hairline bg-background px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                {c.tag}
              </span>
            </div>
            <h3 className="mt-6 font-display text-xl font-semibold tracking-tight">
              {c.name}
            </h3>
            <div className="mt-3 font-display text-3xl font-semibold text-primary">
              {c.outcome}
            </div>
            <p className="mt-3 flex-1 text-sm leading-relaxed text-muted-foreground">
              {c.desc}
            </p>
            <div className="mt-6 inline-flex items-center gap-1 text-xs text-muted-foreground transition-colors group-hover:text-primary">
              Read the breakdown <ArrowUpRight className="h-3.5 w-3.5" />
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------------ */
/* Process                                                             */
/* ------------------------------------------------------------------ */

const PHASES = [
  {
    n: "01",
    name: "Build the Foundation",
    desc: "A fast, conversion-ready website and a fully optimized Google Business Profile — the base every other channel relies on.",
    tags: ["Website", "GBP Optimization"],
  },
  {
    n: "02",
    name: "Get Found",
    desc: "SEO and an automated review system push you up local search results and build trust before the first call.",
    tags: ["SEO", "Google Reviews"],
  },
  {
    n: "03",
    name: "Get Chosen",
    desc: "Targeted Google and Meta campaigns put you in front of people actively looking — and keep you there.",
    tags: ["Google Ads", "Meta Ads"],
  },
  {
    n: "04",
    name: "Capture Every Lead",
    desc: "A connected CRM, booking system, and AI chatbot make sure no inquiry goes unanswered, day or night.",
    tags: ["CRM", "Booking", "AI Chatbot"],
  },
  {
    n: "05",
    name: "Keep Them Coming Back",
    desc: "SMS and email automation re-engage past customers and leads — one-time jobs become repeat revenue.",
    tags: ["SMS", "Email"],
  },
];

function Process() {
  return (
    <Section
      id="process"
      eyebrow="How it works"
      title={
        <>
          From first search to{" "}
          <span className="text-gradient">booked customer</span>.
        </>
      }
      intro="Five phases. Every step builds on the last, so growth compounds instead of resetting every month."
    >
      <div className="space-y-4">
        {PHASES.map((p) => (
          <div
            key={p.n}
            className="hairline shadow-card grid grid-cols-1 gap-6 rounded-2xl bg-surface/60 p-8 md:grid-cols-[auto_1fr_auto] md:items-center"
          >
            <div className="font-display text-5xl font-semibold text-primary/70 md:text-6xl">
              {p.n}
            </div>
            <div>
              <h3 className="font-display text-xl font-semibold tracking-tight md:text-2xl">
                {p.name}
              </h3>
              <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground md:text-base">
                {p.desc}
              </p>
            </div>
            <div className="flex flex-wrap gap-2 md:justify-end">
              {p.tags.map((t) => (
                <span
                  key={t}
                  className="rounded-full border border-hairline bg-background px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------------ */
/* Comparison                                                          */
/* ------------------------------------------------------------------ */

const COMPARE = [
  ["Strategy", "Separate vendors for each channel", "One connected growth system"],
  ["Reporting", "Vanity metrics, monthly PDFs", "Real-time leads & revenue dashboard"],
  ["Lead response", "Manual, hours or days later", "Automated, under 5 minutes"],
  ["Contracts", "Long-term lock-in", "Earn your business every month"],
  ["Focus", "Activity — posts, clicks, impressions", "Outcomes — booked customers, revenue"],
  ["Communication", "Account manager, slow turnaround", "Direct access to your growth team"],
];

function Comparison() {
  return (
    <Section
      eyebrow="Why choose us"
      title={
        <>
          A different kind of{" "}
          <span className="text-gradient">agency relationship</span>.
        </>
      }
      intro="Traditional agencies sell services. We engineer outcomes — and we measure ourselves the same way you do."
    >
      <div className="hairline shadow-card overflow-hidden rounded-2xl bg-surface/60">
        <div className="grid grid-cols-3 border-b border-hairline bg-background/40 px-6 py-4 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          <div />
          <div>Traditional agency</div>
          <div className="text-primary">Northbound</div>
        </div>
        {COMPARE.map(([label, trad, us]) => (
          <div
            key={label}
            className="grid grid-cols-3 items-center gap-4 border-b border-hairline px-6 py-5 last:border-b-0"
          >
            <div className="font-display text-sm font-semibold md:text-base">
              {label}
            </div>
            <div className="flex items-start gap-2 text-sm text-muted-foreground">
              <Minus className="mt-0.5 h-4 w-4 flex-shrink-0" />
              <span>{trad}</span>
            </div>
            <div className="flex items-start gap-2 text-sm text-foreground">
              <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-primary" />
              <span>{us}</span>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------------ */
/* Industries marquee                                                  */
/* ------------------------------------------------------------------ */

const INDUSTRIES = [
  "Roofing", "HVAC", "Dental", "Auto Repair", "Contractors", "Salons",
  "Landscaping", "Restaurants", "Trucking", "Elder Care", "Bakeries",
  "Med Spas", "Law Firms", "Real Estate",
];

function Industries() {
  const doubled = [...INDUSTRIES, ...INDUSTRIES];
  return (
    <section className="relative overflow-hidden border-y border-hairline bg-surface/40 py-14">
      <div className="mx-auto max-w-7xl px-6 mb-6">
        <div className="inline-flex items-center gap-2 rounded-full border border-hairline bg-surface/60 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full bg-primary animate-ticker" />
          Industries we grow
        </div>
      </div>
      <div className="relative">
        <div className="flex w-max animate-marquee gap-3">
          {doubled.map((i, idx) => (
            <span
              key={idx}
              className="rounded-full border border-hairline bg-background px-5 py-2.5 font-display text-sm text-muted-foreground"
            >
              {i}
            </span>
          ))}
        </div>
        <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-background to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-background to-transparent" />
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Testimonials                                                        */
/* ------------------------------------------------------------------ */

const QUOTES = [
  {
    q: "Northbound treated our website like a tool to generate calls, not just a brochure. The booking volume change was obvious within the first month.",
    who: "Owner, roofing company",
    label: "Verbatim from a paid pilot engagement",
  },
  {
    q: "We'd tried three agencies before. This was the first time everything — site, ads, reviews — actually worked together instead of feeling bolted on.",
    who: "Practice manager, dental group",
    label: "Verbatim from a paid pilot engagement",
  },
  {
    q: "The AI chatbot alone paid for itself. We stopped losing after-hours leads to competitors who picked up the phone first.",
    who: "Owner, HVAC company",
    label: "Verbatim from a paid pilot engagement",
  },
];

function Testimonials() {
  return (
    <Section
      eyebrow="What clients say"
      title={
        <>
          Words from{" "}
          <span className="text-gradient">the operators</span> we work with.
        </>
      }
      intro="Full case-study writeups with named clients and audited numbers are in progress; these are verbatim pilot notes."
    >
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {QUOTES.map((q, i) => (
          <figure
            key={i}
            className="hairline shadow-card flex flex-col rounded-2xl bg-surface/60 p-7"
          >
            <div className="flex gap-0.5 text-primary">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-current" />
              ))}
            </div>
            <blockquote className="mt-5 flex-1 font-display text-lg leading-snug text-foreground">
              "{q.q}"
            </blockquote>
            <figcaption className="mt-6 border-t border-hairline pt-4">
              <div className="text-sm font-medium text-foreground">{q.who}</div>
              <div className="mt-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
                {q.label}
              </div>
            </figcaption>
          </figure>
        ))}
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------------ */
/* FAQ                                                                 */
/* ------------------------------------------------------------------ */

const FAQS = [
  {
    q: "What makes this different from a typical marketing agency?",
    a: "Most agencies sell one service in isolation. We design and run the full system — website, visibility, trust, demand, and automation — so every channel reinforces the others instead of competing for budget.",
  },
  {
    q: "Do I need every service, or can I start smaller?",
    a: "Every engagement starts with a strategy call where we identify what's actually limiting growth right now. Some businesses start with just the website and GBP foundation; others are ready for the full system from day one.",
  },
  {
    q: "How long until I see results?",
    a: "Paid channels like Google Ads typically generate leads within the first one to two weeks. Organic channels like SEO and Google Business ranking build over 60–120 days but compound long after the work is done.",
  },
  {
    q: "What industries do you work with?",
    a: "Local, service-based businesses — roofing, HVAC, dental, auto repair, contractors, salons, landscaping, restaurants, trucking, elder care, bakeries, and similar industries where customers search locally before buying.",
  },
  {
    q: "Am I locked into a long-term contract?",
    a: "No. We work month to month because the results should be the reason you stay, not a contract.",
  },
  {
    q: "How do I know what's actually working?",
    a: "You get a live dashboard tracking every lead from first click to booked appointment, plus a direct line to your growth team — no waiting on a monthly report to find out what happened.",
  },
];

function FAQ() {
  return (
    <Section
      eyebrow="FAQ"
      title={
        <>
          Questions we hear before{" "}
          <span className="text-gradient">the first call</span>.
        </>
      }
    >
      <div className="hairline shadow-card overflow-hidden rounded-2xl bg-surface/60">
        <Accordion type="single" collapsible className="w-full">
          {FAQS.map((f, i) => (
            <AccordionItem
              key={i}
              value={`item-${i}`}
              className="border-b border-hairline last:border-b-0 px-6"
            >
              <AccordionTrigger className="py-6 text-left font-display text-base font-semibold hover:no-underline md:text-lg">
                {f.q}
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-sm leading-relaxed text-muted-foreground md:text-base">
                {f.a}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </Section>
  );
}

/* ------------------------------------------------------------------ */
/* Final CTA                                                           */
/* ------------------------------------------------------------------ */

function FinalCTA() {
  return (
    <section id="contact" className="relative py-24 md:py-32">
      <div className="mx-auto max-w-5xl px-6">
        <div className="relative overflow-hidden rounded-3xl border border-hairline bg-surface/70 p-10 text-center md:p-16">
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 bg-hero-radial opacity-80"
          />
          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full border border-hairline bg-background/70 px-3 py-1 font-mono text-[11px] uppercase tracking-widest text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-ember animate-ticker" />
              One free strategy call · No pitch deck
            </div>
            <h2 className="mt-6 font-display text-4xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
              Let's build the system that{" "}
              <span className="text-gradient">grows your business</span>.
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg">
              We'll show you exactly where you're losing customers today, and
              what a connected growth system would look like for your business.
              We take a limited number of engagements each quarter.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <a
                href="/contact"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3.5 text-sm font-medium text-primary-foreground shadow-glow transition-transform hover:-translate-y-px"
              >
                Book Your Free Strategy Call
                <ArrowRight className="h-4 w-4" />
              </a>
              <a
                href="tel:+18326224254"
                className="inline-flex items-center gap-2 rounded-full border border-hairline bg-background/60 px-6 py-3.5 text-sm font-medium text-foreground transition-colors hover:bg-background"
              >
                <Phone className="h-4 w-4" />
                (832) 622-4254
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

